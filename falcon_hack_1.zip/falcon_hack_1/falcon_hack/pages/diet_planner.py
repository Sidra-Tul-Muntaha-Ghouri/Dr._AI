import streamlit as st
from ai71 import AI71
from dotenv import load_dotenv
import os
from llama_index.core import VectorStoreIndex, StorageContext
from llama_index.vector_stores.faiss import FaissVectorStore
from llama_index.core.node_parser import SimpleNodeParser
import pandas as pd

# Load environment variables
load_dotenv()

# Retrieve API key from environment variables
AI71_API_KEY = os.getenv("AI71_API_KEY")

# Set up the AI71 client
client = AI71(AI71_API_KEY)

dtype_dict = {
    'id': 'int64',  
    'name': 'str',
    'substitute0': 'str',
    'substitute1': 'str',
    'substitute2': 'str',
    'substitute3': 'str',
    'substitute4': 'str',
    'sideEffect0': 'str',
    'sideEffect1': 'str',
    'sideEffect2': 'str',
    'sideEffect3': 'str',
    'sideEffect4': 'str',
    'sideEffect5': 'str',
    'sideEffect6': 'str',
    'sideEffect7': 'str',
    'sideEffect8': 'str',
    'sideEffect9': 'str',
    'sideEffect10': 'str',
    'sideEffect11': 'str',
    'sideEffect12': 'str',
    'sideEffect13': 'str',
    'sideEffect14': 'str',
    'sideEffect15': 'str',
    'sideEffect16': 'str',
    'sideEffect17': 'str',
    'sideEffect18': 'str',
    'sideEffect19': 'str',
    'sideEffect20': 'str',
    'sideEffect21': 'str',
    'sideEffect22': 'str',
    'sideEffect23': 'str',
    'sideEffect24': 'str',
    'sideEffect25': 'str',
    'sideEffect26': 'str',
    'sideEffect27': 'str',
    'sideEffect28': 'str',
    'sideEffect29': 'str',
    'sideEffect30': 'str',
    'sideEffect31': 'str',
    'sideEffect32': 'str',
    'sideEffect33': 'str',
    'sideEffect34': 'str',
    'sideEffect35': 'str',
    'sideEffect36': 'str',
    'sideEffect37': 'str',
    'sideEffect38': 'str',
    'sideEffect39': 'str',
    'sideEffect40': 'str',
    'sideEffect41': 'str',
    'use0': 'str',
    'use1': 'str',
    'use2': 'str',
    'use3': 'str',
    'use4': 'str',
    'Chemical Class': 'str',
    'Habit Forming': 'str',
    'Therapeutic Class': 'str',
    'Action Class': 'str'
}

# Load and process CSV file
def load_csv_data(file_path):
    df = pd.read_csv(file_path, dtype=dtype_dict)

    documents = [{"id": row["id"], "content": str(row.to_dict())} for _, row in df.iterrows()]
    return documents

# Create vector index
def create_vector_index(documents):
    parser = SimpleNodeParser()
    nodes = parser.get_nodes_from_documents(documents)
    
    vector_store = FaissVectorStore(dim=512)  # Adjust dimension as needed
    storage_context = StorageContext.from_defaults(vector_store=vector_store)
    index = VectorStoreIndex(nodes, storage_context=storage_context)
    return index

# Load CSV data and create index
csv_file_path = "data/medicine_dataset.csv"  
documents = load_csv_data(csv_file_path)
index = create_vector_index(documents)

# Streamlit UI
st.title(":grey[Dr.] :blue[*AI*] 🩺")
st.subheader(":grey[Diet Planner] 🍎")

# Collect user inputs
gender = st.selectbox("Please enter your Gender", ["Male", "Female"])
age = st.number_input("Please enter your age", min_value=0, max_value=120, step=1)
weight = st.number_input("Please enter your Weight in Kg", min_value=0.0, max_value=300.0, step=0.1)
dietary_pref = st.text_input("Your dietary preferences (e.g., vegetarian, non-vegetarian, vegan, etc.)")
Med_conditions = st.text_input("Any medical conditions or allergies")

# Initialize session state for messages
if "diet_messages" not in st.session_state:
    st.session_state.diet_messages = []

# Function to get AI response
def get_response(user_input):
    # Query the index
    query_engine = index.as_query_engine()
    query_result = query_engine.query(user_input)
    
    # Combine query result with user input
    augmented_input = f"{user_input}\n\nRelevant information: {query_result.response}"
    
    st.session_state.diet_messages.append({"role": "user", "content": augmented_input})
    response_content = ""
    for chunk in client.chat.completions.create(
        messages=st.session_state.diet_messages,
        model="tiiuae/falcon-180B-chat",
        stream=True,
    ):
        delta_content = chunk.choices[0].delta.content
        if delta_content:
            response_content += delta_content
    st.session_state.diet_messages.append({"role": "assistant", "content": response_content})
    return response_content

# Button to generate diet plan
if st.button("Generate Diet Plan"):
    system_message = f"""You are an Expert Diet Planner. Your role is to provide a personalized diet plan for a {gender}
    of age {age} years having weight of {weight} kg. This person prefers {dietary_pref} and has these medical issues:
    {Med_conditions}. Now provide a precise and well-defined diet plan for this person. Remember you have everything
    you need to plan a balanced diet."""
    
    st.session_state.diet_messages = [{"role": "system", "content": system_message}]
    
    response = get_response("Please provide a personalized diet plan based on the information given.")
    st.chat_message("assistant").write(response)

# Display chat messages
for message in st.session_state.diet_messages:
    if message["role"] != "system":
        with st.chat_message(message["role"]):
            st.write(message["content"])

# Chat input for follow-up questions
user_input = st.chat_input("Ask a follow-up question about your diet plan")
if user_input:
    st.chat_message("user").write(user_input)
    response = get_response(user_input)
    st.chat_message("assistant").write(response)