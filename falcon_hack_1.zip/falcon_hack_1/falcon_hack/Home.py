import streamlit as st
from dotenv import load_dotenv
import os

# Load environment variables
load_dotenv()

# Retrieve API key from environment variables
AI71_API_KEY = os.getenv("AI71_API_KEY")

st.set_page_config(page_title="Dr. AI", page_icon="🩺")

with open("styles.css") as f:
    st.markdown(f"<style>{f.read()}</style>", unsafe_allow_html=True)

def main():
    st.title(":grey[Dr.] :blue[*AI*] 🩺")
    
    st.write("""
    Hi there! I'm Dr. AI, your personal virtual healthcare assistant. I'm here to help you with various aspects of your health and wellness journey. 
    Whether you need help planning your diet, creating an exercise routine, or addressing general health concerns, I'm here to assist you.

    Please select the service you are looking for:
    """)
    
    col1, col2, col3 = st.columns(3)

    with col1:
        if st.button("Diet Planner 🍎", use_container_width=True):
            st.switch_page("pages/diet_planner.py")

    with col2:
        if st.button("Exercise Planner 🏋️", use_container_width=True):
            st.switch_page("pages/excercise_planner.py")

    with col3:
        if st.button("General Physician 👨‍⚕️", use_container_width=True):
            st.switch_page("pages/general_physician.py")

if __name__ == "__main__":
    main()
